package controller;

public class AplMain {

	public static void main(String[] args) {
		Controller control = new Controller();

	}

}
