package controller;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import model.Numero;
import view.VentanaPrincipal;

/**
 * Clase Controller
 * 
 * Esta clase en el controlador del proyecto...
 * 
 * @author HRamirez
 * @author JOrtiz
 * 
 * @version 1.4
 */
public class Controller implements ActionListener, MouseListener{

	/**
	 * Es un objeto de tipo VentanaPrincipal....
	 */
	private VentanaPrincipal ventana;
	
	/**
	 * Objeto de N�mero que permite...
	 */
	private Numero num1;
	
	/**
	 * Objeto de N�mero que permite...
	 */
	private Numero num2;
	
	/**
	 * M�todo contructor de la clase Controller	
	 */
	public Controller() {
		ventana = new VentanaPrincipal();
		num1 = new Numero();
		num2 = new Numero();
		asignarOyentes();
	}

	/**
	 * M�todo que asigna los oyentes a los componentes que tienen alguna acci�n
	 */
	public void asignarOyentes() {
		ventana.getPanel_ej1().getBoton_calcular().addActionListener(this);
		ventana.getPanel_ej2().getBoton_calcular().addActionListener(this);
		ventana.getMi11().addActionListener(this);
		ventana.getMi12().addActionListener(this);
		ventana.getMi21().addActionListener(this);
		ventana.getMi22().addActionListener(this);
		ventana.getPanel_ej2().getBoton_calcular().addMouseListener(this);
		ventana.getPanel_ej0().addMouseListener(this);
	}

	/**
	 * M�todo que asigna los operaciones a realizar seg�n sea el caso seleccionado
	 * 
	 * @param e es una objeto de tipo ActionEvent
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		int pos = 0;

		if (command.equals("Menu11") || command.equals("Menu12")) {
			if(command.equals("Menu11")) {
				ventana.getPanel_imagen().cambiarImagen("cama");
			}else if(command.equals("Menu12")) {
				ventana.getPanel_imagen().cambiarImagen("ducha");
			}
			ventana.getContentPane().remove(ventana.getPanel_ej0());
			ventana.getContentPane().remove(ventana.getPanel_ej1());
			ventana.getContentPane().remove(ventana.getPanel_ej2());
			ventana.getContentPane().add(ventana.getPanel_imagen(), BorderLayout.CENTER);
			ventana.getPanel_imagen().setVisible(true);
			ventana.repaint();
		} else if (command.equals("Menu21")) {
			ventana.getContentPane().remove(ventana.getPanel_ej0());
			ventana.getContentPane().remove(ventana.getPanel_ej2());
			ventana.getContentPane().remove(ventana.getPanel_imagen());
			ventana.getContentPane().add(ventana.getPanel_ej1(), BorderLayout.CENTER);
			ventana.getPanel_ej1().setVisible(true);
			ventana.repaint();
		} else if (command.equals("Menu22")) {
			ventana.getContentPane().remove(ventana.getPanel_ej0());
			ventana.getContentPane().remove(ventana.getPanel_ej1());
			ventana.getContentPane().remove(ventana.getPanel_imagen());
			ventana.getContentPane().add(ventana.getPanel_ej2(), BorderLayout.CENTER);
			ventana.getPanel_ej2().setVisible(true);
			ventana.repaint();
		} else if (command.equals("CALCULAR")) {
			String aux = ventana.getPanel_ej1().getCampo1().getText();
			int n = Integer.parseInt(aux);
			num1.setN(n);
			String r = num1.fibonacciN();
			ventana.getPanel_ej1().getL2().setText("Soluci�n : " + r);
		} else if (command.equals("MAYOR")) {
			String aux1 = ventana.getPanel_ej2().getCampo1().getText();
			String aux2 = ventana.getPanel_ej2().getCampo2().getText();
			int n1 = Integer.parseInt(aux1);
			num1.setN(n1);
			int n2 = Integer.parseInt(aux2);
			num2.setN(n2);
			String r = num1.numeroMayor(num2);
			ventana.getPanel_ej2().getL4().setText(r);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getSource().equals(ventana.getPanel_ej2().getBoton_calcular())) {
			System.out.println("INGRES� A LA ZONA DEL BOT�N");
		}else if(e.getSource().equals(ventana.getPanel_ej0())){
			System.out.println("SELECCIONE EN OPERACIONES LO QUE QUIERA");
		}		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
