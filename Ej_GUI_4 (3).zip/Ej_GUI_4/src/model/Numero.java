package model;

/**
 * Clase Numero
 * 
 * Clase del modelo que permite .....
 * 
 * @author HRamirez
 * @author JRuiz
 *
 * @version 1.4
 */
public class Numero {
	
	/**
	 * Variable de tipo entero que permite....
	 */
	private int n;
	
	/**
	 * M�todo constructor
	 */
	public Numero() {
		n = 0;
	}
	
	/**
	 * M�todo que determina el fibonacci de un n�mero
	 * 
	 * @return Un String donde va la serie de fibonacci
	 */
	public String fibonacciN() {
		String r = "";
		int a = 0;
		int b = 1;
		
		for ( int i = 0 ; i < n ; i++ ) {
			a = a + b;
			b = a - b;
			r = r + " "+ b;
		}
		
		return r;
	}
	
	/**
	 * M�todo que determina el n�mero mayor de dos n�meros
	 * @param otro Objeto de tipo n�mero
	 * @return <ul>
	 * 			<li> true: retorna cadena de texto donde indica que el primer n�mero es el mayor
	 * 			<li> true: retorna cadena de texto donde indica que el segundo n�mero es el mayor
	 *		   </ul> 
	 */
	public String numeroMayor(Numero otro) {
		if(n>otro.n) {
			return "El n�mero mayor es el "+n;
		}else {
			return "El n�mero mayor es el "+otro.n;
		}
	}

	/**
	 * M�todo Get del atributo n
	 * @return N valor del atributo n
	 */
	public int getN() {
		return n;
	}

	/**
	 * M�todo Set del atributo n
	 * @param n variable de tipo entero
	 */
	public void setN(int n) {
		this.n = n;
	}
	
	
}
