package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Panel_Ej0 extends JPanel {
	
	public Panel_Ej0() {
		setLayout(new BorderLayout());
		
		inicializarComponentes();
		
		setVisible(true);
	}

	public void inicializarComponentes() {
		
		setBackground(Color.red);
		
		setBorder( new TitledBorder( "M�dulo de Ejercicio XXXX:" ) ) ;
				
	}
}
