package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class PanelImagen extends JPanel {
	
	private JLabel l1;
		
	public PanelImagen() {
		setLayout(new FlowLayout());
		setSize(584, 438);
		
		inicializarComponentes();
		
		setVisible(false);
	}

	public void inicializarComponentes() {
		
		setBackground(Color.CYAN);
		setBorder( new TitledBorder( "Imagen del Elemento:" ) ) ;
				
		l1 = new JLabel();
		add(l1);
		
	}
	
	public void cambiarImagen(String elem) {
		ImageIcon im = new ImageIcon(getClass().getResource("/imagenes/"+elem+".jpg"));
		ImageIcon icono = new ImageIcon(im.getImage().getScaledInstance(this.getWidth()-30, this.getHeight()-30, Image.SCALE_DEFAULT));
		l1.setIcon(icono);
	}

	public JLabel getL1() {
		return l1;
	}

	public void setL1(JLabel l1) {
		this.l1 = l1;
	}
	
}
