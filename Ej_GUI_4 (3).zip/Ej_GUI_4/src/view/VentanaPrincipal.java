package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.management.loading.PrivateClassLoader;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class VentanaPrincipal extends JFrame {

	private Panel_Ej2 panel_ej2;
	private Panel_Ej1 panel_ej1;
	private PanelImagen panel_imagen;
	private Panel_Ej0 panel_ej0;
	
	private JMenuBar menubar;
    private JMenu menuprincipal;
    private JMenu menu1;
    private JMenu menu2;
    private JMenuItem mi11;
    private JMenuItem mi12;
    private JMenuItem mi21;
    private JMenuItem mi22;

	public VentanaPrincipal() {
		setTitle("Programa Mostrar Menu Desplegable");
		setSize(600, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.red);
		getContentPane().setLayout(new BorderLayout(10, 10));

		inicializarComponentes();
		setResizable(true);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public void inicializarComponentes() {
		menubar=new JMenuBar();
		menubar.setBackground(Color.GREEN);
        setJMenuBar(menubar);
        
        menuprincipal=new JMenu("Opciones");
        menubar.add(menuprincipal);
        
        menu1=new JMenu("Imagen de programa");
        menuprincipal.add(menu1);
        
        menu2=new JMenu("Ejecusi�n de programa");
        menuprincipal.add(menu2);
        
        mi11=new JMenuItem("Cama");
        mi11.setActionCommand("Menu11");
        menu1.add(mi11);
        
        mi12=new JMenuItem("Ducha");
        mi12.setActionCommand("Menu12");
        menu1.add(mi12);
        
        mi21=new JMenuItem("Programa1");
        mi21.setActionCommand("Menu21");
        menu2.add(mi21);
        
        mi22=new JMenuItem("Programa2");
        mi22.setActionCommand("Menu22");
        menu2.add(mi22);
        
		
        panel_ej0 = new Panel_Ej0();
		getContentPane().add(panel_ej0, BorderLayout.CENTER);
		panel_ej1 = new Panel_Ej1();
		panel_ej2 = new Panel_Ej2();
		panel_imagen = new PanelImagen();
		
	}
	
	public PanelImagen getPanel_imagen() {
		return panel_imagen;
	}

	public void setPanel_imagen(PanelImagen panel_imagen) {
		this.panel_imagen = panel_imagen;
	}

	public JMenuBar getMenubar() {
		return menubar;
	}

	public void setMenubar(JMenuBar menubar) {
		this.menubar = menubar;
	}

	public JMenu getMenuprincipal() {
		return menuprincipal;
	}

	public void setMenuprincipal(JMenu menuprincipal) {
		this.menuprincipal = menuprincipal;
	}

	public JMenu getMenu1() {
		return menu1;
	}

	public void setMenu1(JMenu menu1) {
		this.menu1 = menu1;
	}

	public JMenu getMenu2() {
		return menu2;
	}

	public void setMenu2(JMenu menu2) {
		this.menu2 = menu2;
	}

	public JMenuItem getMi11() {
		return mi11;
	}

	public void setMi11(JMenuItem mi11) {
		this.mi11 = mi11;
	}

	public JMenuItem getMi12() {
		return mi12;
	}

	public void setMi12(JMenuItem mi12) {
		this.mi12 = mi12;
	}

	public JMenuItem getMi21() {
		return mi21;
	}

	public void setMi21(JMenuItem mi21) {
		this.mi21 = mi21;
	}

	public JMenuItem getMi22() {
		return mi22;
	}

	public void setMi22(JMenuItem mi22) {
		this.mi22 = mi22;
	}

	public Panel_Ej0 getPanel_ej0() {
		return panel_ej0;
	}

	public void setPanel_ej0(Panel_Ej0 panel_ej0) {
		this.panel_ej0 = panel_ej0;
	}

	public Panel_Ej2 getPanel_ej2() {
		return panel_ej2;
	}

	public void setPanel_ej2(Panel_Ej2 panel_ej2) {
		this.panel_ej2 = panel_ej2;
	}

	public Panel_Ej1 getPanel_ej1() {
		return panel_ej1;
	}

	public void setPanel_ej1(Panel_Ej1 panel_ej1) {
		this.panel_ej1 = panel_ej1;
	}

	public void imprimirMensaje(String m) {
		JOptionPane.showMessageDialog(null, m);
	}

	public int captuarDato(String m) {
		int n = 0;
		String aux = JOptionPane.showInputDialog(m);
		n = Integer.parseInt(aux);
		return n;
	}
}
