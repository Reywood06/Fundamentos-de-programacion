package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import javafx.geometry.HorizontalDirection;

public class Panel_Ej2 extends JPanel {
	
	private JLabel l1;
	private JLabel l2;
	private JLabel l3;
	private JLabel l4;
	private JTextField campo1;
	private JTextField campo2;
	private JButton boton_calcular;
	
	
	
	
	public Panel_Ej2() {
		setLayout(new GridLayout(4,1,5,5));
		
		inicializarComponentes();
		
		setVisible(false);
	}

	public void inicializarComponentes() {
		
		setBackground(Color.white);
		
		setBorder( new TitledBorder( "M�dulo de Ejercicio 2:" ) ) ;
				
		JPanel aux1 = new JPanel();
		aux1.setLayout(new GridLayout(1,2));
		l1 = new JLabel("N�mero: ");
		aux1.add(l1);
		campo1 = new JTextField();
		System.out.println("INGRES� A LA ZONA DEL BOT�N");
		aux1.add(campo1);
		add(aux1);
		
		JPanel aux2 = new JPanel();
		aux2.setLayout(new GridLayout(1,2));
		l2 = new JLabel("N�mero: ");
		aux2.add(l2);
		campo2 = new JTextField();
		aux2.add(campo2);
		add(aux2);
		
		JPanel aux3 = new JPanel();
		aux3.setLayout(null);
		boton_calcular = new JButton("Mayor?: ");
		boton_calcular.setBounds(30, 30, 90, 30);
		boton_calcular.setBackground(Color.magenta);
		boton_calcular.setActionCommand("MAYOR");
		aux3.add(boton_calcular);
		add(aux3);
		
		JPanel aux4 = new JPanel();
		aux4.setLayout(new GridLayout(1,2));
		l3 = new JLabel("Soluci�n: ");
		aux4.add(l3);
		l4 = new JLabel();
		aux4.add(l4);
		add(aux4);
		
	}

	public JLabel getL1() {
		return l1;
	}

	public void setL1(JLabel l1) {
		this.l1 = l1;
	}

	public JLabel getL2() {
		return l2;
	}

	public void setL2(JLabel l2) {
		this.l2 = l2;
	}

	public JLabel getL3() {
		return l3;
	}

	public void setL3(JLabel l3) {
		this.l3 = l3;
	}

	public JLabel getL4() {
		return l4;
	}

	public void setL4(JLabel l4) {
		this.l4 = l4;
	}

	public JTextField getCampo1() {
		return campo1;
	}

	public void setCampo1(JTextField campo1) {
		this.campo1 = campo1;
	}

	public JTextField getCampo2() {
		return campo2;
	}

	public void setCampo2(JTextField campo2) {
		this.campo2 = campo2;
	}

	public JButton getBoton_calcular() {
		return boton_calcular;
	}

	public void setBoton_calcular(JButton boton_calcular) {
		this.boton_calcular = boton_calcular;
	}
	
	

}
