package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Panel_Ej1 extends JPanel {
	
	private JLabel l1;
	private JLabel l2;
	private JTextField campo1;
	private JButton boton_calcular;
	
	
	
	
	public Panel_Ej1() {
		setLayout(new BorderLayout(5,5));
		
		inicializarComponentes();
		
		setVisible(false);
	}

	public void inicializarComponentes() {
		
		setBackground(Color.white);
		
		setBorder( new TitledBorder( "M�dulo de Ejercicio 1:" ) ) ;
				
		JPanel aux = new JPanel();
		aux.setLayout(new GridLayout(1,2));
		
		l1 = new JLabel("N�mero: ");
		aux.add(l1);
		
		campo1 = new JTextField();
		aux.add(campo1);
		
		add(aux, BorderLayout.NORTH);
		
		JPanel aux2 = new JPanel();
		aux2.setLayout(null);
		boton_calcular = new JButton("Calcular: ");
		boton_calcular.setBounds(30, 30, 90, 30);
		boton_calcular.setBackground(Color.CYAN);
		boton_calcular.setActionCommand("CALCULAR");
		aux2.add(boton_calcular, BorderLayout.CENTER);
		add(aux2);
		
		l2 = new JLabel("Soluci�n: ");
		add(l2, BorderLayout.SOUTH);
		
	}

	public JLabel getL1() {
		return l1;
	}

	public void setL1(JLabel l1) {
		this.l1 = l1;
	}

	public JLabel getL2() {
		return l2;
	}

	public void setL2(JLabel l2) {
		this.l2 = l2;
	}

	public JTextField getCampo1() {
		return campo1;
	}

	public void setCampo1(JTextField campo1) {
		this.campo1 = campo1;
	}

	public JButton getBoton_calcular() {
		return boton_calcular;
	}

	public void setBoton_calcular(JButton boton_calcular) {
		this.boton_calcular = boton_calcular;
	}
	
	

}
