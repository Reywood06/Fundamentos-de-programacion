package Model;

public class Ejercicio19 {
	
	private int Entero1=0;
	private int Entero2=0;
	
	public Ejercicio19() {
		this.Entero1=0;
		this.Entero2=0;
	}

	public int getEntero1() {
		return Entero1;
	}

	public void setEntero1(int entero1) {
		Entero1 = entero1;
	}

	public int getEntero2() {
		return Entero2;
	}

	public void setEntero2(int entero2) {
		Entero2 = entero2;
	}
}

