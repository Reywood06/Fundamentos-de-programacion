package Model;

public class Ejercicio20 {
	
private int Entero = 0;
private int digito1 =0;
private int digito2 =0;
private int digito3 =0;

public Ejercicio20() {
	
	this.Entero=0;
	this.digito1=0;
	this.digito2=0;
	this.digito3=0;
}

public int getEntero() {
	return Entero;
}

public void setEntero(int entero) {
	Entero = entero;
}

public int getDigito1() {
	return digito1;
}

public void setDigito1(int digito1) {
	this.digito1 = digito1;
}

public int getDigito2() {
	return digito2;
}

public void setDigito2(int digito2) {
	this.digito2 = digito2;
}

public int getDigito3() {
	return digito3;
}

public void setDigito3(int digito3) {
	this.digito3 = digito3;
}
}
