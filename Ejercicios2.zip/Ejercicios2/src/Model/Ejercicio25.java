package Model;

public class Ejercicio25 {

	private int Entero =0;
	
	public Ejercicio25() {
		
		this.Entero=0;
	}

	public int getEntero() {
		return Entero;
	}

	public void setEntero(int entero) {
		Entero = entero;
	}
	
}
