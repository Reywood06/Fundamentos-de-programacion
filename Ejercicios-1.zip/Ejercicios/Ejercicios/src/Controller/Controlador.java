package Controller;

import Model.*;
import View.Vista;

public class Controlador {

	private Ejercicio5 ej5;
	private Ejercicio9 ej9;
	private Ejercicio10 ej10;
	private Ejercicio15 ej15;
	private Ejercicio19 ej19;
	private Vista v;
	private int seleccion;


	public Controlador() {

		ej5 = new Ejercicio5();
		ej9 = new Ejercicio9();
		ej10 = new Ejercicio10();
		ej15 = new Ejercicio15();
		ej19 = new Ejercicio19();
		v = new Vista();
		seleccion = -1;
		funcionar();
		
	}
	
	//Ejercicio5
		public String leerDigitos(int entero) {
			String respuesta = "";
			
			v.mostrarinfo("Ingrese un numero entero: ");
			entero = v.leerDato();
			ej5.setEntero(entero);
			
			
			if(entero > 9 && entero < 100) {
				int digito1 = entero/10;
				int digito2 = entero%10;

				
				if (digito1%2 == 0 && digito2%2 == 0) {
					respuesta = "Ambos n�meros son pares";
				}
				
				else if (digito1%2 == 0) {
					respuesta = "Solo el primer digito es par";
				}
				
				else {
					respuesta = "Solo el segundo digito es par";
				}
			}
			else {
				respuesta = "Ninguno de los dos es par";
				
			}
			
			return respuesta;
		}
	
	//Ejercicio9
	public String Ejercicio1(int Entero) {
		String respuesta = "";
		
		v.mostrarinfo("Ingresa un numero entero");
		Entero = v.leerDato();		
		ej9.setEntero(Entero);
		
		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;
		
			if(digito1%digito2 == 0&& digito2%digito1==0 ) {
				respuesta = "los dos son multiplos";
				
			}
			
			
			
			else {
				respuesta = digito1+" no es multiplo de " +digito2; }
			
			
		}
			
		else {
			respuesta = "Ingrese un numero de dos digitos:";
		}
		
		return respuesta;
	}
	
	//Ejercicio10
	public String Ejercicio2(int Entero) {
		String respuesta = "";
		
		v.mostrarinfo("Ingresa un numero entero:");
		Entero = v.leerDato();		
		ej10.setEntero(Entero);
		
		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;
		
			if(digito1==digito2 ) {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+" Son iguales";
				
			}
			else {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+" no son iguales";
			}
			
		}
		
		else {
			respuesta = "Ingrese un n�mero de dos digitos: ";
		}
		
		return respuesta;
	}
	
	//Ejercicio15
	public String Ejercicio3(int Entero) {
		String respuesta = "";
		v.mostrarinfo("Digite un n�mero entero de 3 digitos");
		Entero = v.leerDato();
		ej15.setEntero(Entero);
		
		if (Entero>99 && Entero<1000) {
			int digito1 = Entero /100;
			int digito2 = (Entero%100)/10;
			int digito3 = (Entero%100)%10;
			int suma = digito1+digito2+digito3;
			
			respuesta = "El resultado de la suma de sus tres d�gitos es: "+suma;
			
		}
		
		return respuesta;
	}
	
	//Ejercicio19
	public String ejercicio19(int entero1, int entero2) {
		String respuesta = "";
		v.mostrarinfo("Digite un n�mero entero");
		entero1 = v.leerDato();
		ej19.setEntero1(entero1);
		v.mostrarinfo("Digite un segundo n�mero entero");
		entero2 = v.leerDato();
		ej19.setEntero1(entero2);
		
		if (entero1 > entero2) {
			v.mostrarinfo("Ingrese un tercer n�mero entero");
			entero2 = v.leerDato();
			ej19.setEntero2(entero2);
			
			if(entero1 > entero2) {
				respuesta = "El mayor es: "+entero1;
			}
			else {
				respuesta = "El mayor es: "+entero2;
			}
		}
		else {
			v.mostrarinfo("Ingrese un tercer n�mero entero");
			entero1 = v.leerDato();
			ej19.setEntero1(entero1);
			
			if (entero2 > entero1) {
				respuesta = "El mayor es: "+entero2;
			}
			else {
				respuesta = "El mayor es: "+entero1;
			}
		}

			
		return respuesta;
	}
	
	//Ejercicio20
	public String ejercicio20() {
		String respuesta = "";
		
		return respuesta;
	}
	
	
	public void funcionar() {
		
		while(seleccion !=0) {
			
			v.mostrarinfo("Seleccione una de las opciones que se listan en el men� a continuaci�n:");
			v.mostrarinfo("1- Leer un n�mero entero de dos d�gitos y determinar si ambos d�gitos son pares.");
			v.mostrarinfo("2- Leer un n�mero entero de dos d�gitos y determinar si un d�gito es m�ltiplo del otro.");
			v.mostrarinfo("3- Leer un n�mero entero de dos d�gitos y determinar si los dos d�gitos son iguales.");
			v.mostrarinfo("4- Leer un n�mero entero de tres d�gitos y determinar a cu�nto es igual la suma de sus d�gitos.");
			v.mostrarinfo("5- Leer tres n�meros enteros y determinar cu�l es el mayor. Usar solamente dos variables.");
			v.mostrarinfo("0- SALIR");
			
			seleccion = v.leerDato();
			
			switch(seleccion) {
			case 1: String Ej5 = leerDigitos(ej5.getEntero());
					v.mostrarinfo(Ej5);
					break;
					
			case 2: String Ej1=Ejercicio1(ej9.getEntero());
					v.mostrarinfo(Ej1);
					break;
					
			case 3: String Ej2=Ejercicio2(ej10.getEntero());
					v.mostrarinfo(Ej2);
					break;
			
			case 4: String Ej3=Ejercicio3(ej15.getEntero());
					v.mostrarinfo(Ej3);
					break;
					
			case 5: String Ej19 = ejercicio19(ej19.getEntero1(), ej19.getEntero2());
					v.mostrarinfo(Ej19);
					break;
					
			}

			
		}
				
	}
}
