package Model;

public class Ejercicio19 {
	
	private int entero1;
	private int entero2;

	
	public Ejercicio19() {
		this.entero1 = 0;
		this.entero2 = 0;
		
	}

	public int getEntero1() {
		return entero1;
	}

	public void setEntero1(int entero1) {
		this.entero1 = entero1;
	}

	public int getEntero2() {
		return entero2;
	}

	public void setEntero2(int entero2) {
		this.entero2 = entero2;
	}


	
		

}
