package Model;

public class Ejercicio9 {

	private int Entero;
	private int Digito1;
	private int Digito2;


	public Ejercicio9() {

		this.Entero = 0;
		this.Digito1 = 0;
		this.Digito2 = 0;


	}


	public int getEntero() {
		return Entero;
	}


	public void setEntero(int entero) {
		Entero = entero;
	}


	public int getDigito1() {
		return Digito1;
	}


	public void setDigito1(int digito1) {
		Digito1 = digito1;
	}


	public int getDigito2() {
		return Digito2;
	}


	public void setDigito2(int digito2) {
		Digito2 = digito2;
	}

}
