package Model;

public class Ejercicio3 {
	
	

	private int Entero;
	


	public Ejercicio3() {

		this.Entero = 0;
		
	}



	public int getEntero() {
		return Entero;
	}



	public void setEntero(int entero) {
		Entero = entero;
	}


}
