package Controller;

import Model.*;
import View.Vista;

public class Controlador {

	private Ejercicio1 ej1;
	private Ejercicio2 ej2;
	private Ejercicio3 ej3;
	private Vista v;


	public Controlador() {

		ej1 = new Ejercicio1();
		ej2 = new Ejercicio2();
		ej3 = new Ejercicio3();
		v = new Vista();
		funcionar();
		
	}

	public String Ejercicio1(int Entero) {
		String respuesta = "";
		
		v.mostrarinfo("Ingresa un numero entero");
		Entero = v.leerDato();		
		ej1.setEntero(Entero);
		
		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;
		
			if(digito1%digito2 == 0&& digito2%digito1==0 ) {
				respuesta = "los dos son multiplos";
				
			}
			
			
			
			else {
				respuesta = digito1+" no es multiplo de " +digito2; }
			
			
		}
			
		else {
			respuesta = "Ingrese un numero de dos digitos";
		}
		
		return respuesta;
	}
	public String Ejercicio2(int Entero) {
		String respuesta = "";
		
		v.mostrarinfo("Ingresa un numero entero");
		Entero = v.leerDato();		
		ej2.setEntero(Entero);
		
		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;
		
			if(digito1==digito2 ) {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+"Son iguales";
				
			}
			else {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+"No son iguales";
			}
			
		}
		
		else {
			respuesta = "Ingrese un numero de dos digitos";
		}
		
		return respuesta;
	}
	
	
	public String Ejercicio3(int Entero) {
		String respuesta ="";
		v.mostrarinfo("Digite un numero entero de 3 digitos");
		Entero = v.leerDato();
		ej3.setEntero(Entero);
		
		if (Entero>99 && Entero<1000) {
			int digito1 = Entero %10;
			int digito2 = digito1 %10;
			int digito3 = digito2/10;
			System.out.println(digito1);
			System.out.println(digito2);
			System.out.println(digito3);
		}
		
		return respuesta;
	}
	
	
	public void funcionar() {
		
		String Ej1=Ejercicio1(ej1.getEntero());
		v.mostrarinfo(Ej1);
		String Ej2=Ejercicio2(ej2.getEntero());
		v.mostrarinfo(Ej2);
		String Ej3=Ejercicio3(ej3.getEntero());
		v.mostrarinfo(Ej3);		
	}
}
