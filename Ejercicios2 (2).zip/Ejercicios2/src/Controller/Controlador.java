package Controller;

import Model.*;
import View.Vista;

public class Controlador {

	private Ejercicio5 ej5;
	private Ejercicio9 ej9;
	private Ejercicio10 ej10;
	private Ejercicio15 ej15;
	private Ejercicio19 ej19;
	private Ejercicio20 ej20;
	private Ejercicio25 ej25;
	private Ejercicio29 ej29;
	private Ejercicio30 ej30;
	private Ejercicio35 ej35;
	private Ejercicio39 ej39;
	private Ejercicio40 ej40;
	private Ejercicio45 ej45;
	private Ejercicio49 ej49;
	private Ejercicio50 ej50;
	private Vista v;
	private int seleccion;


	public Controlador() {

		ej5  = new Ejercicio5();
		ej9  = new Ejercicio9();
		ej10 = new Ejercicio10();
		ej15 = new Ejercicio15();
		ej19 = new Ejercicio19();
		ej20 = new Ejercicio20();
		ej25 = new Ejercicio25();
		ej29 = new Ejercicio29();
		ej30 = new Ejercicio30();
		ej35 = new Ejercicio35();
		ej39 = new Ejercicio39();	
		ej40 = new Ejercicio40();
		ej45 = new Ejercicio45();
		ej49 = new Ejercicio49();
		ej50 = new Ejercicio50();
		v = new Vista();
		seleccion = -1;
		funcionar();

	}

	public String Ejercicio5(int Entero) {
		String respuesta = "";

		v.mostrarinfo("Ingrese un numero entero: ");
		Entero = v.leerDato();
		ej5.setEntero(Entero);


		if(Entero > 9 && Entero < 100) {
			int digito1 = Entero/10;
			int digito2 = Entero%10;


			if (digito1%2 == 0 && digito2%2 == 0) {
				respuesta = "Ambos n�meros son pares";
			}

			else if (digito1%2 == 0) {
				respuesta = "Solo el primer digito es par";
			}

			else {
				respuesta = "Solo el segundo digito es par";
			}
		}
		else {
			respuesta = "Ninguno de los dos es par";

		}

		return respuesta;
	}

	public String Ejercicio9(int Entero) {
		String respuesta = "";

		v.mostrarinfo("Ingresa un numero entero");
		Entero = v.leerDato();		
		ej9.setEntero(Entero);

		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;

			if(digito1%digito2 == 0&& digito2%digito1==0 ) {
				respuesta = "los dos son multiplos";

			}



			else {
				respuesta = digito1+" no es multiplo de " +digito2; }


		}

		else {
			respuesta = "Error, intenta digitar un numero de dos digitos";
		}

		return respuesta;
	}
	public String Ejercicio10(int Entero) {
		String respuesta = "";


		v.mostrarinfo("Ingresa un numero entero");
		Entero = v.leerDato();		
		ej10.setEntero(Entero);

		if (Entero>9 && Entero <100) {
			int digito1= Entero/10;
			int digito2 = Entero%10;

			if(digito1==digito2 ) {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+" Son iguales";

			}
			else {
				respuesta = "Los digitos  " +digito1+" y " +digito2+" del entero "+Entero+" No son iguales";
			}

		}

		else {
			respuesta = "Error, intenta digitar un numero de dos digitos";

		}

		return respuesta;

	}



	public String Ejercicio15(int Entero) {
		String respuesta ="";
		v.mostrarinfo("Digite un numero entero de 3 digitos");
		Entero = v.leerDato();
		ej15.setEntero(Entero);

		if (Entero>99 && Entero<1000) {
			int digito1 = Entero /100;
			int digito2 = (Entero%100) /10;
			int digito3 = (Entero%100)%10;
			int suma = 0;

			suma = digito1+digito2+digito3;
			respuesta = "La suma es "+suma;

		}
		else {

			respuesta = "Error, intenta digitar un numero de 3 digitos";
		}


		return respuesta;
	}


	public String Ejercicio19(int Entero1, int Entero2) {
		String respuesta="";

		v.mostrarinfo("Digite su primer numero entero");
		Entero1=v.leerDato();
		ej19.setEntero1(Entero1);
		v.mostrarinfo("Digite su segundo numero entero");
		Entero2=v.leerDato();
		ej19.setEntero2(Entero2);


		if (Entero1 > Entero2) {
			v.mostrarinfo("Ingrese un tercer n�mero entero");
			Entero2 = v.leerDato();
			ej19.setEntero2(Entero2);

			if(Entero1 > Entero2) {
				respuesta = "El mayor es: "+Entero1;
			}
			else {
				respuesta = "El mayor es: "+Entero2;
			}
		}
		else {
			v.mostrarinfo("Ingrese un tercer n�mero entero");
			Entero1 = v.leerDato();
			ej19.setEntero1(Entero1);

			if (Entero2 > Entero1) {
				respuesta = "El mayor es: "+Entero2;
			}
			else {
				respuesta = "El mayor es: "+Entero1;
			}
		}





		return respuesta;
	}

	public String Ejercicio20(int Entero) {
		String respuesta ="";
		v.mostrarinfo("Digite un numero entero de 3 digitos");
		Entero = v.leerDato();
		ej20.setEntero(Entero);

		if (Entero>99 && Entero<1000) {
			int digito1 = Entero /100;
			int digito2 = (Entero%100) /10;
			int digito3 = (Entero%100)%10;

			int max= 0;
			int med=0;
			int min=0;

			if(digito1 < digito2 && digito3 > digito1) {
				max= digito2;
				med=digito3;
				min=digito1; 
				respuesta= "En orden ascendente es "+min +med +max;}


			else if (digito2 < digito3 && digito2 > digito1){
				max=digito3;
				med=digito2;
				min=digito1;
				respuesta= "En orden ascendente es "+min +med +max;}

			else if (digito1>digito2&& digito2<digito3) {
				max=digito1;
				med=digito3;
				min=digito2;
				respuesta= "En orden ascendente es "+min +med +max;
			}
			else if(digito2>digito1&&digito1>digito3) {
				max=digito2;
				med=digito1;
				min=digito3;
				respuesta= "En orden ascendente es "+min +med +max;}

			else if(digito3>digito2&&digito2<digito1) {
				max=digito3;
				med=digito1;
				min=digito2;
				respuesta= "En orden ascendente es "+min +med +max;

			}

			else  {
				max=digito1;
				med=digito2;
				min=digito3;
				respuesta= "En orden ascendente es "+min +med +max;
			}

		}


		else {

			respuesta = "Error, intenta digitar un numero de tres digitos";
		}


		return respuesta;
	}
	public String Ejercicio25(int Entero) {
		String respuesta ="";
		v.mostrarinfo("Digita un numero entero de 3 digitos");
		Entero = v.leerDato();
		ej25.setEntero(Entero);

		if (Entero>99 && Entero<1000) {
			int digito1 = Entero /100;
			int digito2 = (Entero%100)/10;
			int digito3 = (Entero%100)%10;

			if(digito1 == digito2+digito3 || digito1 == digito3+digito2) {

				respuesta ="El digito "+digito1+" es igual a la suma de los digitos "+digito2+ " y "
						+digito3;

			}
			else if(digito2 == digito1+digito3 || digito2 == digito3+digito1) {
				respuesta ="El digito "+digito2+" es igual a la suma de los digitos "+digito1+ " y "
						+digito3;

			}
			else if(digito3 == digito1+digito2 || digito3 == digito2+digito1) {
				respuesta ="El digito "+digito3+" es igual a la suma de los digitos "+digito1+ " y "
						+digito2;
			}
			else {
				respuesta="No es igual a la suma de los digitos";
			}
		}

		return respuesta;
	}
	public String Ejercicio29(int Entero) {
		String respuesta="";
		v.mostrarinfo("Digite un numero entero de 5 digitos");
		Entero=v.leerDato();
		ej29.setEntero(Entero);

		if(Entero>=10000&&Entero<100000) {
			int digito1=Entero/10000;
			int digito2=(Entero%10000)/1000;
			int digito3=(Entero%10000)%1000/100;
			int digito4=(Entero%10000)%1000%100/10;
			int digito5=(Entero%10000)%1000%100%10;
			
			if(digito1==digito5&&digito2==digito4) {
				respuesta="El numero: "+Entero+" Es capicuo";
				
			}
			else {
				respuesta="El numero: "+Entero+" no es capicuo";
			}
			}
		
		return respuesta;
		
	}
	public String Ejercicio30(int Entero) {
		String respuesta="";
		v.mostrarinfo("Ingrese un numero entero de 4 digitos");
		Entero =v.leerDato();
		ej30.setEntero(Entero);

		if (Entero>1000&&Entero<10000) {
			int digito1= Entero/1000;
			int digito2= (Entero%1000)/100;
			int digito3= (Entero%1000)%100/10;
			int digito4= (Entero%1000)%100%10%10;

			if(digito2==digito3) {
				respuesta="El digito "+digito2+" es igual al digito "+digito3;
			}
			else {
				respuesta="El digito "+digito2+" no es igual al digito "+digito3;
			}
		}

		return respuesta;
	}

	public String Ejercicio35(int Entero) {
		String respuesta="";
		v.mostrarinfo("Ingrese un numero entero de 2 digitos");
		Entero =v.leerDato();
		ej35.setEntero25(Entero);


		if (Entero>9 && Entero<100){
			int digito1=Entero/10;
			int digito2=Entero%10;

			v.mostrarinfo("Digito 1 = "+digito1);
			v.mostrarinfo("Digito 2 = "+digito2);
		}

		else {
			respuesta="Error, intenta digitar un numero de dos digitos";
		}
		return respuesta;
	}

	public String Ejercicio39(int Entero1, int Entero2, int Entero3) {
		String respuesta ="";
		v.mostrarinfo("Digita un numero entero ");
		Entero1 = v.leerDato();
		ej39.setEntero1(Entero1);
		v.mostrarinfo("Digita un segundo numero entero ");
		Entero2 = v.leerDato();
		ej39.setEntero2(Entero2);
		v.mostrarinfo("Digita un tercer numero entero ");
		Entero3 = v.leerDato();
		ej39.setEntero3(Entero3);
		int digito1 = Entero1 /100;
		int digito2 = (Entero1%100)/10;
		int digito3 = (Entero1%100)%10;
		int digito4 = Entero2 /100;
		int digito5 = (Entero2%100)/10;
		int digito6 = (Entero2%100)%10;
		int digito7 = Entero3 /100;
		int digito8 = (Entero3%100)/10;
		int digito9 = (Entero3%100)%10;

		if (Entero1>0 && Entero1<1000 && Entero2>0&&Entero2<100&&Entero3>0&&Entero3<1000) {

			if(digito1==digito4&&digito4==digito7)
				v.mostrarinfo("Son iguales");
		}
		else if(digito2==digito5&&digito5==digito8)
			v.mostrarinfo("Son iguales");

		else if(digito3==digito6 && digito6==digito9) {
			v.mostrarinfo("Son iguales");
		}
		else {
			respuesta="No son iguales";
		}



		return respuesta;
	}
	public String Ejercicio40(int Entero1, int Entero2){
		String respuesta = "";
		v.mostrarinfo("Digita un numero entero ");
		Entero1 = v.leerDato();
		ej40.setEntero1(Entero1);
		v.mostrarinfo("Digita un segundo numero entero ");
		Entero2 = v.leerDato();
		ej40.setEntero2(Entero2);
		int resta = Entero1 - Entero2;
			if(resta <= 10 && resta >0) {
			if(Entero1>Entero2) {
				v.mostrarinfo("Los datos son: ");
				for(int i=Entero2+1; i<Entero1; i++) {
					v.mostrarinfo(i+" ");
				}
			}
			else {
				v.mostrarinfo("Los datos son: ");
				for(int i=Entero1+1; i<Entero2; i++) {
					v.mostrarinfo(i+" ");
				}
			}
		
		}
		else {
			respuesta = "La diferencia entre los dos n�meros es mayor a 10";
		}
		
		
		
		return respuesta;
	}

	public String Ejercicio45(int Entero) {
		String respuesta="";
		v.mostrarinfo("Digita un numero entero");
		Entero=v.leerDato();
		ej45.setEntero(Entero);
		int digito1=Entero/10;
		int digito2=Entero%10;
		int suma= digito1+digito2;

		if(Entero>9 && Entero<100) {
			if (Entero%2==0) {
				v.mostrarinfo("La suma de los digitos es: "+suma);
			}
			else {
				v.mostrarinfo("No es par");
			}
		}
		else {
			respuesta="Error, digita un numero de 2 digitos";
		}
		if(Entero>9 && Entero<100) {
			
			
			
			int raiz = (int) Math.sqrt(Entero);
			
		
			for(int i=2; i<=raiz; i++){
				if((Entero%i) == 0){
					v.mostrarinfo(Entero+" no es primo");
					break;
					
				}
				else {
					v.mostrarinfo("El ultimo digito es:"+digito2);
					break;
				}
			}
			
			
			
		}
		
		
		if(Entero>9 && Entero<100) {
			if (Entero%5==0&&Entero<30) {
			v.mostrarinfo("El primer digito es: "+digito1);
			}
			else {
				v.mostrarinfo("No es multiplo de 5");
			}
			
		}
		else {
			respuesta="Error, digita un numero de 2 digitos";
		}
	


		return respuesta;
	}
	
	public String Ejercicio49(int Entero) {
		String respuesta="";
		v.mostrarinfo("Digita un numero entero maximo de 4 digitos");
		Entero=v.leerDato();
		ej49.setEntero(Entero);
		
		
		if(Entero>0&&Entero<10) {
			if(Entero%4==0) {
				int raiz = (int) Math.sqrt(Entero);
				
				
				for(int i=2; i<=raiz; i++){
					if((Entero%i) == 0){
						respuesta=Entero+" no es primo";
						break;
						
					}
					else {
						respuesta=Entero+" es primo";
						break;
				}
				}
			}
			else {
				respuesta="No es multiplo de 4";
			}
			
		}
		
		else if (Entero>=10&&Entero<100) {
			int digito1=Entero/10;
			int digito2=Entero%10;
			 if(Entero%4==0) {
					int raiz = (int) Math.sqrt(digito2);
					
					
					for(int i=2; i<=raiz; i++){
						if((digito2%i) == 0){
							respuesta=digito2+" no es primo";
							break;
							
						}
						else {
							respuesta=digito2+" es primo";
							break;
					}
					}
				}
			 else {
					respuesta="No es multiplo de 4";
				}
			
		}
		
		
		else if (Entero>=100&&Entero<1000) {
			 int digito1=Entero/100;
			 int digito2=(Entero%100)/10;
			 int digito3=(Entero%100)%10;
			 if(Entero%4==0) {
					int raiz = (int) Math.sqrt(digito3);
					
					
					for(int i=2; i<=raiz; i++){
						if((digito3%i) == 0){
							respuesta=digito3+" no es primo";
							break;
							
						}
						else {
							respuesta=digito3+" es primo";
							break;
					}
					}
				}
			 else {
					respuesta="No es multiplo de 4";
				}
		}
		else if (Entero>=1000&&Entero<10000) {
			int digito1= Entero/1000;
			int digito2= (Entero%1000)/100;
			int digito3= (Entero%1000)%100/10;
			int digito4= (Entero%1000)%100%10%10;
			
			if(Entero%4==0) {
				int raiz = (int) Math.sqrt(digito4);
				
				
				for(int i=2; i<=raiz; i++){
					if((digito4%i) == 0){
						respuesta=digito4+" no es primo";
						break;
						
					}
					else {
						respuesta=digito4+" es primo";
						break;
				}
				}
			}
			else {
				respuesta="No es multiplo de 4";
			}
		}
		else {
			respuesta="Digita un numero entero maximo de 4 digitos";
		}
		return respuesta;
	}
	
	public String Ejercicio50(int Entero) {
		String respuesta="";
		v.mostrarinfo("Digite un numero entero (maximo de 2 digitos)");
		Entero=v.leerDato();
		ej50.setEntero(Entero);
		
		
	if(Entero>0 &&Entero<=100) {
		int digito1=Entero/10;
		int digito2=Entero%10;
	
		
		if(Entero%4==0) {
			v.mostrarinfo("La mitad de "+Entero+" es "+Entero/2);
			
		}
		else {
			v.mostrarinfo("No es multiplo de 4");
		}
		if(Entero%5==0) {
			v.mostrarinfo("El cuadrado de "+Entero+" es "+Entero*Entero);
		}
		else {
			v.mostrarinfo("No es multiplo de 5");
		}
		if(Entero%6==0) {
			v.mostrarinfo("El primer digito de "+Entero+" es "+digito1);
		}
		else {
			respuesta="No es multiplo de 6";
		}
		
		
		
	}
	else {
		respuesta="Error, intenta digitar un numero de 2 digitos";
	}
	return respuesta;
	}


		
	public void funcionar() {


		while(seleccion !=0) {

			v.mostrarinfo("");
			v.mostrarinfo("Seleccione alguno de los siguientes ejercicios que se listan en el men� a continuaci�n:");
			v.mostrarinfo("5 -Leer un n�mero entero de dos d�gitos y determinar si ambos d�gitos son pares");
			v.mostrarinfo("9 -Leer un numero enteror de dos digitos y determinar si cada uno es multiplo del otro");
			v.mostrarinfo("10-Leer un n�mero entero de dos d�gitos y determinar si un d�gito es m�ltiplo del otro");
			v.mostrarinfo("15-Leer un n�mero entero de tres d�gitos y determinar a cu�nto es igual la suma de sus d�gitos");
			v.mostrarinfo("19-Leer tres n�meros enteros y determinar cu�l es el mayor.");
			v.mostrarinfo("20-Leer tres n�meros enteros y mostrarlos ascendentemente");
			v.mostrarinfo("25-Leer un n�mero entero de tres d�gitos y determinar si alguno de sus d�gitos es igual a la suma de los otros dos.");
			v.mostrarinfo("29-Leer un n�mero entero de cinco d�gitos y determinar si es un n�mero capic�o.");
			v.mostrarinfo("30-Leer un n�mero entero de cuatro d�gitos y determinar si el segundo d�gito es igual al pen�ltimo.");
			v.mostrarinfo("35-Leer un n�mero entero de dos d�gitos e indicar cada una de los digitos");
			v.mostrarinfo("39-Leer tres n�meros enteros y determina si el pen�ltimo d�gito de los tres n�meros es igual.");
			v.mostrarinfo("40-Leer dos n�meros enteros y si la diferencia entre los dos es menor o igual a 10 entonces mostrar en pantalla todos los enteros comprendidos entre el menor y el mayor de los n�meros le�dos.");
			v.mostrarinfo("45-Leer un n�mero entero de 2 d�gitos y si es par mostrar en pantalla la suma de sus d�gitos, si es primo y menor que 10 mostrar en pantalla su �ltimo d�gito y si es m�ltiplo de 5 y menor que 30 mostrar en pantalla el primer d�gito");
			v.mostrarinfo("49-Leer un numero entero y si es multiplo de 4 determinar si su ultimo digito es primo");
			v.mostrarinfo("50-Leer un numero entero y si es multiplo de 4 mostrar en pantalla su mitad, si es multiplo de 5 mostrar en pantalla su cuadrado y si es multiplo es 6 mostrar en pantalla su primer digito.");
			v.mostrarinfo("0 -SALIR");
			v.mostrarinfo("");

			seleccion = v.leerDato();

			switch (seleccion) {
			case 5:
				String Ej5 = Ejercicio5(ej5.getEntero());
				v.mostrarinfo(Ej5);
				break;
			case 9:
				String Ej9=Ejercicio9(ej9.getEntero());
				v.mostrarinfo(Ej9);
				break;
			case 10:
				String Ej10=Ejercicio10(ej10.getEntero());
				v.mostrarinfo(Ej10);
				break;
			case 15:
				String Ej15=Ejercicio15(ej15.getEntero());
				v.mostrarinfo(Ej15);
				break;
			case 19:
				String Ej19=Ejercicio19(ej19.getEntero1(),ej19.getEntero2());
				v.mostrarinfo(Ej19);
				break;
			case 20:
				String Ej20=Ejercicio20(ej20.getEntero());
				v.mostrarinfo(Ej20);
				break;
			case 25:
				String Ej25=Ejercicio25(ej25.getEntero());
				v.mostrarinfo(Ej25);
				break;
			case 29:
				String Ej29=Ejercicio29(ej29.getEntero());
				v.mostrarinfo(Ej29);
				break;
			case 30:
				String Ej30=Ejercicio30(ej30.getEntero());
				v.mostrarinfo(Ej30);
				break;
			case 35:
				String Ej35= Ejercicio35(ej35.getEntero25());
				v.mostrarinfo(Ej35);
				break;
			case 39:
				String Ej39= Ejercicio39(ej39.getEntero1(),ej39.getEntero2(),ej39.getEntero3());
				v.mostrarinfo(Ej39);
				break;
			case 40:
				String Ej40=Ejercicio40(ej40.getEntero1(),ej40.getEntero2());
				v.mostrarinfo(Ej40);
				break;
			case 45:
				String Ej45=Ejercicio45(ej45.getEntero());
				v.mostrarinfo(Ej45);
				break;
			case 49:
				String Ej49=Ejercicio49(ej49.getEntero());
				v.mostrarinfo(Ej49);
				break;
			case 50:
				String Ej50=Ejercicio50(ej50.getEntero());
				v.mostrarinfo(Ej50);
				break;
			}
		}
		v.mostrarinfo("Gracias, vuelva pronto!");
	}
}
