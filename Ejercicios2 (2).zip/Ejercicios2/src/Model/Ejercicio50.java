package Model;

public class Ejercicio50 {

	private int Entero;
	
	public Ejercicio50() {
		this.Entero=0;
		
	}

	public int getEntero() {
		return Entero;
	}

	public void setEntero(int entero) {
		Entero = entero;
	}
}
