package Model;

public class Ejercicio45 {
	private int Entero;
	
	public Ejercicio45() {
		this.Entero=0;
	}

	public int getEntero() {
		return Entero;
	}

	public void setEntero(int entero) {
		Entero = entero;
	}

}
