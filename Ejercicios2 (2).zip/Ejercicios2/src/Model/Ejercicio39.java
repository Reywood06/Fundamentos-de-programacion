package Model;

public class Ejercicio39 {
private int Entero1;
private int Entero2;
private int Entero3;


	public Ejercicio39() {
		this.Entero1=0;
		this.Entero2=0;
		this.Entero3=0;
	}


	public int getEntero1() {
		return Entero1;
	}


	public void setEntero1(int entero1) {
		Entero1 = entero1;
	}


	public int getEntero2() {
		return Entero2;
	}


	public void setEntero2(int entero2) {
		Entero2 = entero2;
	}


	public int getEntero3() {
		return Entero3;
	}


	public void setEntero3(int entero3) {
		Entero3 = entero3;
	}
}
