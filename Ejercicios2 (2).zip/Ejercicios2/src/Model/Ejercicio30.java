package Model;

public class Ejercicio30 {
	private int Entero  =0;
	
	public Ejercicio30() {
		this.Entero=0;
	}

	public int getEntero() {
		return Entero;
	}

	public void setEntero(int entero) {
		Entero = entero;
	}

}
