package Model;

public class Ejercicio15 {
	
	

	private int Entero;
	


	public Ejercicio15() {

		this.Entero = 0;
		
	}



	public int getEntero() {
		return Entero;
	}



	public void setEntero(int entero) {
		Entero = entero;
	}


}
