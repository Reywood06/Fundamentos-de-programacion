package Model;

public class Ejercicio35 {
	
	private int Entero25;
	
	public Ejercicio35() {
		
		this.Entero25=0;
	}

	public int getEntero25() {
		return Entero25;
	}

	public void setEntero25(int entero25) {
		Entero25 = entero25;
	}

}
