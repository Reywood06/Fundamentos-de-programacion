package co.edu.unbosque.controller;

import co.edu.unbosque.model.Ejercicio5;
import co.edu.unbosque.view.Vista;

public class Controller {
	
	private Ejercicio5 ej5;
	private Vista v;
	
	public Controller() {
		ej5 = new Ejercicio5();
		v = new Vista();
		
		funcionar();
		
	}
	
	//Ejercicio5
	public String leerDigitos(int entero) {
		String respuesta = "";
		
		v.mostrarInfo("Ingrese un numero entero: ");
		entero = v.leerDato();
		ej5.setEntero(entero);
		
		
		if(entero > 9 && entero < 100) {
			int digito1 = entero/10;
			int digito2 = entero%10;

			
			if (digito1%2 == 0 && digito2%2 == 0) {
				respuesta = "Ambos n�meros son pares";
			}
			
			else if (digito1%2 == 0) {
				respuesta = "Solo el primer digito es par";
			}
			
			else {
				respuesta = "Solo el segundo digito es par";
			}
		}
		else {
			respuesta = "Ninguno de los dos es par";
			
		}
		
		return respuesta;
	}
	
	public void funcionar() {
		String Ej5 = leerDigitos(ej5.getEntero());
		v.mostrarInfo(Ej5);
	}

}
