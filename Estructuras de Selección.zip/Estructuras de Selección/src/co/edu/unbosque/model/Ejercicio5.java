package co.edu.unbosque.model;

public class Ejercicio5 {
	
	private int entero;

	
	
	public Ejercicio5() {
		this.entero = 0;
		
		
	}


	public int getEntero() {
		return entero;
	}


	public void setEntero(int entero) {
		this.entero = entero;
	}



}
