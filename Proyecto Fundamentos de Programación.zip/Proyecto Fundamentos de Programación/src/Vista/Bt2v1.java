package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

public class Bt2v1 extends JButton{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 40);

	public Bt2v1() {
		
		setText("SALIR");
		setBounds(520,520,240,80);
		setBackground(new Color(160, 160, 160));
		setActionCommand("salir");
		setFont(fuente);
		setVisible(true);
	}
}
