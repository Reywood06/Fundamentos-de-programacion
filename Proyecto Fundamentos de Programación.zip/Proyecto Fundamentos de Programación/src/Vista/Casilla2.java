package Vista;

import javax.swing.JPanel;

public class Casilla2 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Casilla2() {
		setOpaque(false);
		setVisible(true);
	}

}
