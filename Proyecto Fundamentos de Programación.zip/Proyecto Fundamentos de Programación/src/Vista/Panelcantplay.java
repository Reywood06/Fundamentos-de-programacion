package Vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Panelcantplay extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 40);
	Font fuentetx = new Font("Alagard", Font.BOLD, 19);
	
	JLabel tx1 = new JLabel();
	
	JRadioButton b1 = new JRadioButton();
	JRadioButton b2 = new JRadioButton();
	JRadioButton b3 = new JRadioButton();
	JRadioButton b4 = new JRadioButton();
	JLabel l1 = new JLabel();
	JLabel l2 = new JLabel();
	JLabel l3 = new JLabel();
	JLabel l4 = new JLabel();
	
	public JRadioButton getB1() {
		return b1;
	}

	public void setB1(JRadioButton b1) {
		this.b1 = b1;
	}

	public JRadioButton getB2() {
		return b2;
	}

	public void setB2(JRadioButton b2) {
		this.b2 = b2;
	}

	public JRadioButton getB3() {
		return b3;
	}

	public void setB3(JRadioButton b3) {
		this.b3 = b3;
	}

	public JRadioButton getB4() {
		return b4;
	}

	public void setB4(JRadioButton b4) {
		this.b4 = b4;
	}

	public Panelcantplay() {
		
		setBounds(650,360,290,200);
		setBackground(new Color(250,235,195));
		setLayout(null);
		tx1.setBounds(20,20,250,50);
		tx1.setText("<html>Selecciona la cantidad de jugadores<html>");
		tx1.setFont(fuentetx);
		tx1.setVisible(true);
		
		b1.setBounds(30,135,50,50);
		b1.setText("1");
		b1.setBackground(new Color(250,235,195));
		b1.setForeground(Color.black);
		b1.setFont(fuentetx);
		b1.setVisible(true);
		
		b2.setBounds(90,135,50,50);
		b2.setText("2");
		b2.setBackground(new Color(250,235,195));
		b2.setForeground(Color.black);
		b2.setFont(fuentetx);
		b2.setVisible(true);
		
		b3.setBounds(150,135,50,50);
		b3.setText("3");
		b3.setBackground(new Color(250,235,195));
		b3.setForeground(Color.black);
		b3.setFont(fuentetx);
		b3.setVisible(true);
		
		b4.setBounds(210,135,50,50);
		b4.setText("4");
		b4.setBackground(new Color(250,235,195));
		b4.setForeground(Color.black);
		b4.setFont(fuentetx);
		b4.setVisible(true);
		
		ButtonGroup bg = new ButtonGroup();
		
		bg.add(b1);
		bg.add(b2);
		bg.add(b3);
		bg.add(b4);
		
		l1.setBounds(30,75,50,50);
		BufferedImage bi1 = null;

		try {
			bi1 = ImageIO.read(new File("src/Agua.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado1 = bi1.getScaledInstance(l1.getWidth(), l1.getHeight(), Image.SCALE_SMOOTH);
		l1.setIcon(new ImageIcon(redimensionado1));
		l1.setVisible(true);
		
		l2.setBounds(90,75,50,50);
		BufferedImage bi2 = null;
		
		try {
			bi2 = ImageIO.read(new File("src/Tierra.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image redimensionado2 = bi2.getScaledInstance(l2.getWidth(), l2.getHeight(), Image.SCALE_SMOOTH);
		l2.setIcon(new ImageIcon(redimensionado2));
		l2.setVisible(true);
		
		l3.setBounds(150,75,50,50);
		BufferedImage bi3 = null;
		
		try {
			bi3 = ImageIO.read(new File("src/Aire.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image redimensionado3 = bi3.getScaledInstance(l3.getWidth(), l3.getHeight(), Image.SCALE_SMOOTH);
		l3.setIcon(new ImageIcon(redimensionado3));
		l3.setVisible(true);
		
		l4.setBounds(210,75,50,50);
		BufferedImage bi4 = null;
		
		try {
			bi4 = ImageIO.read(new File("src/Fuego.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image redimensionado4 = bi4.getScaledInstance(l4.getWidth(), l4.getHeight(), Image.SCALE_SMOOTH);
		l4.setIcon(new ImageIcon(redimensionado4));
		l4.setVisible(true);
		
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(tx1);
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		setVisible(true);
		
	}
}
