package Vista;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Panelbotonv4 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	JLabel marco = new JLabel();
	Bt1v4 b1 = new Bt1v4();
	
	public Panelbotonv4() {
		setBounds(154,660,60,60);
		setLayout(null);
		marco.setBounds(0,0,60,60);
		BufferedImage bi = null;

		try {
			bi = ImageIO.read(new File("src/marco.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado = bi.getScaledInstance(marco.getWidth(), marco.getHeight(), Image.SCALE_SMOOTH);
		marco.setIcon(new ImageIcon(redimensionado));
		marco.setVisible(true);
		
		add(b1);
		add(marco);
		setVisible(true);
	}

}
