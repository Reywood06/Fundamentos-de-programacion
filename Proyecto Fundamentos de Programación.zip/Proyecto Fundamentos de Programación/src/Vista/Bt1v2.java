package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;

public class Bt1v2 extends JButton{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 35);

	public Bt1v2() {
		
		setText("Continuar");
		setBounds(530,600,220,50);
		setBackground(new Color(160,160,160));
		setActionCommand("continuar");
		setFont(fuente);
		setVisible(true);
	}
}
