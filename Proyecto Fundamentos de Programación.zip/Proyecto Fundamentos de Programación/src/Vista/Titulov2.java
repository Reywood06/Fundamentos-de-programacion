package Vista;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class Titulov2 extends JLabel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Font fuente = new Font("Alagard", Font.BOLD, 70);

	public Titulov2() {

		setText("Ingrese los datos.");
		setFont(fuente);
		setBounds(340, 50, 600, 80);
		setForeground(new Color(150, 70, 70));
		setVisible(true);
	}
}
