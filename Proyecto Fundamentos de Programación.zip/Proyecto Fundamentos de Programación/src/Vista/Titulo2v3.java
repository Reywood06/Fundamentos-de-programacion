package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Titulo2v3 extends JLabel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 70);
	
	public Titulo2v3() {
		
		setText("Selecciona tu personaje.");
		setFont(fuente);
		setBounds(210,55,850,80);
		setForeground(new Color(0,0,0));
		setVisible(true);
	}

}
