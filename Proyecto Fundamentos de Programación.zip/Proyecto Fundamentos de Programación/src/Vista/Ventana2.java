package Vista;

import Modelo.*;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ventana2 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Tablero tb1 = new Tablero();
	Titulov2 t2 = new Titulov2();
	Panelcyfv2 pcf = new Panelcyfv2();
	Panelcantplay pcp = new Panelcantplay();
	Reglas r = new Reglas();
	Bt1v2 b1 = new Bt1v2();

	public Tablero getTb1() {
		return tb1;
	}

	public void setTb1(Tablero tb1) {
		this.tb1 = tb1;
	}

	public Bt1v2 getB1() {
		return b1;
	}

	public void setB1(Bt1v2 b1) {
		this.b1 = b1;
	}

	public Panelcyfv2 getPcf() {
		return pcf;
	}

	public void setPcf(Panelcyfv2 pcf) {
		this.pcf = pcf;
	}

	public Panelcantplay getPcp() {
		return pcp;
	}

	public void setPcp(Panelcantplay pcp) {
		this.pcp = pcp;
	}

	public Ventana2() {

		setBounds(0, 0, 1280, 760);
		setLayout(null);
		setResizable(false);

		JLabel img = new JLabel();
		img.setBounds(0, 0, 1280, 720);

		BufferedImage bi = null;

		try {
			bi = ImageIO.read(new File("src/f2.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
		img.setIcon(new ImageIcon(redimensionado));
		img.setVisible(true);
		
		add(b1);
		add(pcf);
		add(pcp);
		add(r);
		add(t2);
		add(img);
	}
}
