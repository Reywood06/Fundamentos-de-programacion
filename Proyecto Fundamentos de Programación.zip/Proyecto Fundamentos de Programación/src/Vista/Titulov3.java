package Vista;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class Titulov3 extends JLabel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 70);
	
	public Titulov3() {
		
		setText("Selecciona tu personaje.");
		setFont(fuente);
		setBounds(215,50,850,80);
		setForeground(new Color(150,70,70));
		setVisible(true);
	}
}
