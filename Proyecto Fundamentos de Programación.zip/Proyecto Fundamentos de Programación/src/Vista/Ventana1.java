package Vista;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ventana1 extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Bt2v1 b2 = new Bt2v1();
	Bt1v1 b1 = new Bt1v1();
	Titulov1 t1 = new Titulov1();
	Titulo2v1 t2 = new Titulo2v1();

	public Bt2v1 getB2() {
		return b2;
	}


	public void setB2(Bt2v1 b2) {
		this.b2 = b2;
	}


	public Bt1v1 getB1() {
		return b1;
	}


	public void setB1(Bt1v1 b1) {
		this.b1 = b1;
	}


	public Ventana1() {
		setBounds(0, 0, 1280, 760);
		setLayout(null);
		setResizable(false);
		
		JLabel img = new JLabel();
		img.setBounds(0, 0, 1280, 720);

		BufferedImage bi = null;

		try {
			bi = ImageIO.read(new File("src/hola.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
		img.setIcon(new ImageIcon(redimensionado));
		img.setVisible(true);

		add(t1);
		add(t2);
        add(b2);
        add(b1);
        add(img);
	}
}
