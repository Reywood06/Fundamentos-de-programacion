package Vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ventana4 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Panel1v4 juego = new Panel1v4();
	JPanel juego2 = new JPanel();
	private int columnas;
	private int filas;
	ArrayList<Casilla> casillas = new ArrayList<>();
	ArrayList<Casilla2> casillas2 = new ArrayList<>();
	private Color color1;
	private Color color2;
	Paneldadov4 pd = new Paneldadov4();
	Panelbotonv4 pb = new Panelbotonv4();
	File imgfondo[] = { new File("src/Mapaagua.png"), new File("src/Mapatierra.png"), new File("src/Mapaaire.png"),
			new File("src/Mapafuego.png")};
	JLabel fondo = new JLabel();
	int aux;
	int med;
	
	public File[] getImgfondo() {
		return imgfondo;
	}

	public void setImgfondo(File[] imgfondo) {
		this.imgfondo = imgfondo;
	}

	public JLabel getFondo() {
		return fondo;
	}

	public void setFondo(JLabel fondo) {
		this.fondo = fondo;
	}

	public int getAux() {
		return aux;
	}

	public void setAux(int aux) {
		this.aux = aux;
	}

	public int getMed() {
		return med;
	}

	public void setMed(int med) {
		this.med = med;
	}

	public Color getColor1() {
		return color1;
	}

	public void setColor1(Color color1) {
		this.color1 = color1;
	}

	public Color getColor2() {
		return color2;
	}

	public void setColor2(Color color2) {
		this.color2 = color2;
	}

	public int getColumnas() {
		return columnas;
	}

	public void setColumnas(int columnas) {
		this.columnas = columnas;
	}

	public int getFilas() {
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	public Ventana4() {

		setBounds(0, 0, 1280, 760);
		setResizable(false);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		fondo.setBounds(0,0,1280,720);
		juego2.setBounds(10, 10, 700, 700);
		juego2.setOpaque(false);
		juego2.setLayout(null);
		juego.add(juego2);
		add(juego);
	}

	public void medida() {
		
		if (columnas > filas) {
			aux = columnas;
		} else if (filas > columnas) {
			aux = filas;
		} else {
			aux = columnas;
		}

		med = juego2.getHeight()/aux;
		
	}
	public void dibujartablero() {
		
		int m1 = (juego2.getWidth() - (columnas * med)) / 2;
		int m2 = (juego2.getHeight() - (filas * med)) / 2;

		JLabel marco = new JLabel();

		int ancho = columnas * med;
		int alto = filas * med;

		marco.setBounds((juego2.getWidth() - ancho) / 2, (juego2.getHeight() - alto) / 2, ancho + 20, alto + 20);

		BufferedImage bi = null;

		try {
			bi = ImageIO.read(new File("src/marco.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado = bi.getScaledInstance(marco.getWidth(), marco.getHeight(), Image.SCALE_SMOOTH);
		marco.setIcon(new ImageIcon(redimensionado));
		marco.setVisible(true);
		
		juego.add(marco);

		for (int j = 0; j < filas; j++) {
			for (int i = 0; i < columnas; i++) {
				if (i % 2 == 0 && j % 2 == 0) {
					Casilla c = new Casilla();
					Casilla2 c2 = new Casilla2();
					c.setSize(med, med);
					c.setLocation((med * i) + m1, (med * j) + m2);
					c.setBackground(color1);
					c.setLayout(null);
					c.setVisible(true);
					c2.setSize(med, med);
					c2.setLocation((med * i) + m1, (med * j) + m2);
					c2.setLayout(null);
					c2.setVisible(true);
					juego2.add(c2);
					juego2.add(c);
					casillas.add(c);
					casillas2.add(c2);
				} else if (i % 2 != 0 && j % 2 != 0) {
					Casilla c = new Casilla();
					Casilla2 c2 = new Casilla2();
					c.setSize(med, med);
					c.setLocation((med * i) + m1, (med * j) + m2);
					c.setBackground(color1);
					c.setLayout(null);
					c.setVisible(true);
					c2.setSize(med, med);
					c2.setLocation((med * i) + m1, (med * j) + m2);
					c2.setLayout(null);
					c2.setVisible(true);
					juego2.add(c2);
					juego2.add(c);
					casillas.add(c);
					casillas2.add(c2);
				} else {
					Casilla c = new Casilla();
					Casilla2 c2 = new Casilla2();
					c.setSize(med, med);
					c.setLocation((med * i) + m1, (med * j) + m2);
					c.setBackground(color2);
					c.setLayout(null);
					c.setVisible(true);
					c2.setSize(med, med);
					c2.setLocation((med * i) + m1, (med * j) + m2);
					c2.setLayout(null);
					c2.setVisible(true);
					juego2.add(c2);
					juego2.add(c);
					casillas.add(c);
					casillas2.add(c2);
				}
			}
		}

		Collections.reverse(casillas);
		Collections.reverse(casillas2);

		ArrayList<Integer> auxiliar = new ArrayList<>();
		ArrayList<Integer> auxiliar2 = new ArrayList<>();

		for (int i = 0; i < filas; i++) {
			if (i % 2 == 0) {
				for (int k = columnas * i; k < columnas * (i + 1); k++) {
					auxiliar.add(k);
				}
				auxiliar2.addAll(auxiliar);
				Collections.reverse(auxiliar);

				if (columnas % 2 == 0) {
					for (int j = 0; j < auxiliar.size() / 2; j++) {
						Collections.swap(casillas, auxiliar.get(j), auxiliar2.get(j));
					}
					for (int j = 0; j < auxiliar.size() / 2; j++) {
						Collections.swap(casillas2, auxiliar.get(j), auxiliar2.get(j));
					}
				} else {
					for (int j = 0; j < (auxiliar.size() + 1) / 2; j++) {
						Collections.swap(casillas, auxiliar.get(j), auxiliar2.get(j));
					}
					for (int j = 0; j < (auxiliar.size() + 1) / 2; j++) {
						Collections.swap(casillas2, auxiliar.get(j), auxiliar2.get(j));
					}
				}
				
				auxiliar2.clear();
				auxiliar.clear();
			}
		}
		
		JLabel img = new JLabel();
		img.setSize(med,med);

		BufferedImage b = null;

		try {
			b = ImageIO.read(new File("src/Final.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redi = b.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
		img.setIcon(new ImageIcon(redi));
		img.setVisible(true);
		
		casillas.get(casillas.size()-1).add(img);

		JLabel numero;
		
		Font fuente = new Font("Alagard", Font.BOLD, (med/5));

		for (int j = 0; j < casillas.size(); j++) {
			numero = new JLabel();
			int n = j + 1;
			numero.setText(Integer.toString(n));
			numero.setFont(fuente);
			numero.setBounds(0, 0, ((casillas.get(j).getWidth()) / 3), ((casillas.get(j).getHeight()) / 3));
			numero.setForeground(Color.black);
			casillas.get(j).add(numero);
		}
		
		add(pb);
		add(pd);
		add(fondo);
	}
	
	public void lanzardado() {
		Random r = new Random();
		int valdado = r.nextInt(6)+1;
		
		switch(valdado) {
		case 1:
			BufferedImage bi = null;

			try {
				bi = ImageIO.read(new File("src/dado1.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado = bi.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado));
			break;
		case 2:
			BufferedImage bi2 = null;

			try {
				bi2 = ImageIO.read(new File("src/dado2.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado2 = bi2.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado2));
			break;
		case 3:
			BufferedImage bi3 = null;

			try {
				bi3 = ImageIO.read(new File("src/dado3.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado3 = bi3.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado3));
			break;
		case 4:
			BufferedImage bi4 = null;

			try {
				bi4 = ImageIO.read(new File("src/dado4.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado4 = bi4.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado4));
			break;
		case 5:
			BufferedImage bi5 = null;

			try {
				bi5 = ImageIO.read(new File("src/dado5.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado5 = bi5.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado5));
			break;
		case 6:
			BufferedImage bi6 = null;

			try {
				bi6 = ImageIO.read(new File("src/dado6.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}

			Image redimensionado6 = bi6.getScaledInstance(pd.getCaradado().getWidth(), pd.getCaradado().getHeight(), Image.SCALE_SMOOTH);
			pd.getCaradado().setIcon(new ImageIcon(redimensionado6));
			break;
		}
	}
}