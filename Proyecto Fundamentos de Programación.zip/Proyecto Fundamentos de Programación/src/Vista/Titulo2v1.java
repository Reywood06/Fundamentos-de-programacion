package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Titulo2v1 extends JLabel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 140);
	
	public Titulo2v1() {
		
		setText("PIXELDOM");
		setFont(fuente);
		setBounds(270,130,720,120);
		setForeground(new Color(0,0,0));
		setVisible(true);
	}
}
