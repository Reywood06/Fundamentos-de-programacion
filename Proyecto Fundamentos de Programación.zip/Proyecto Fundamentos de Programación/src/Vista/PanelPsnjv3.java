package Vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelPsnjv3 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	JPanel pj = new JPanel();
	JButton bp1 = new JButton();
	JButton bp2 = new JButton();
	JButton bp3 = new JButton();
	JButton bp4 = new JButton();
	JLabel txt = new JLabel();
	JTextField nombrejg = new JTextField();
	
	public JTextField getNombrejg() {
		return nombrejg;
	}

	public void setNombrejg(JTextField nombrejg) {
		this.nombrejg = nombrejg;
	}

	public JPanel getPj() {
		return pj;
	}

	public void setPj(JPanel pj) {
		this.pj = pj;
	}

	public JButton getBp1() {
		return bp1;
	}

	public void setBp1(JButton bp1) {
		this.bp1 = bp1;
	}

	public JButton getBp2() {
		return bp2;
	}

	public void setBp2(JButton bp2) {
		this.bp2 = bp2;
	}

	public JButton getBp3() {
		return bp3;
	}

	public void setBp3(JButton bp3) {
		this.bp3 = bp3;
	}

	public JButton getBp4() {
		return bp4;
	}

	public void setBp4(JButton bp4) {
		this.bp4 = bp4;
	}

	public JLabel getTxt() {
		return txt;
	}

	public void setTxt(JLabel txt) {
		this.txt = txt;
	}

	Font fuente = new Font("Alagard", Font.BOLD, 20);
	
	public PanelPsnjv3() {
		
		setSize(225,420);
		setLayout(null);
		pj.setBounds(0,0,225,225);
		pj.setLayout(new GridLayout(2,2));
		
		bp1.setIcon(new ImageIcon("src/ReinaCara.png"));
		bp1.setActionCommand("reina");
		bp1.setBackground(Color.white);
		bp1.setVisible(true);
		
		bp2.setIcon(new ImageIcon("src/ReyCara.png"));
		bp2.setActionCommand("rey");
		bp2.setBackground(Color.white);
		bp2.setVisible(true);
		
		bp3.setIcon(new ImageIcon("src/CaballeroCara.png"));
		bp3.setActionCommand("caballero");
		bp3.setBackground(Color.white);
		bp3.setVisible(true);
		
		bp4.setIcon(new ImageIcon("src/BufonCara.png"));
		bp4.setActionCommand("bufon");
		bp4.setBackground(Color.white);
		bp4.setVisible(true);
		
		ButtonGroup bg = new ButtonGroup();
		
		bg.add(bp1);
		bg.add(bp2);
		bg.add(bp3);
		bg.add(bp4);
		
		txt.setBounds(10,240,205,50);
		txt.setText("Nombre del jugador:");
		txt.setFont(fuente);
		nombrejg.setBounds(20,310,185,50);
		nombrejg.setFont(fuente);
		
		
		pj.add(bp1);
		pj.add(bp2);
		pj.add(bp3);
		pj.add(bp4);
		
		pj.setVisible(true);
		add(nombrejg);
		add(txt);
		add(pj);
	}
}
