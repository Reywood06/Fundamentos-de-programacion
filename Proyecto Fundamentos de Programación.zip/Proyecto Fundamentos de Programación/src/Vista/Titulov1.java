package Vista;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class Titulov1 extends JLabel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 140);

	public Titulov1() {
		
		setText("PIXELDOM");
		setFont(fuente);
		setBounds(280,120,720,120);
		setForeground(new Color(150,70,70));
		setVisible(true);
	}
}
