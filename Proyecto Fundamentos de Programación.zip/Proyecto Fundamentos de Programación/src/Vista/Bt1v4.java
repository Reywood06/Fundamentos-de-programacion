package Vista;

import java.awt.Color;

import javax.swing.JButton;

public class Bt1v4 extends JButton{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Bt1v4() {
		setBounds(10,10,40,40);
		setBackground(new Color(150,0,0));
		setActionCommand("lanzar");
		setVisible(true);
	}

}
