package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Reglas extends JLabel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Font fuente = new Font("Alagard", Font.BOLD, 20);
	
	public Reglas() {
		setBounds(340,140,600,200);
		setText("<html>Reglas del juego: El jugador debe elegir el tipo de tablero que jugará asignando la cantidad de filas y columnas que desea y escogiendo la cantidad de jugadores, el icono y nombre de cada uno. Una vez el juego empiece todas las fichas estarán en la primera casilla, el objetivo es llegar a la última casilla encontrando escaleras que lo acercaran a la meta si supera el desafio o serpientes que lo alejarán si no lo supera.<html>");
		setFont(fuente);
		setForeground(Color.white);
		setVisible(true);
	}

}
