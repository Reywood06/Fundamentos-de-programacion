package Vista;

import Modelo.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ventana3 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	ArrayList<Player> players = new ArrayList<>();
	Player p;
	Bt1v3 b1 = new Bt1v3();
	Titulov3 t1 = new Titulov3();
	Titulo2v3 t2 = new Titulo2v3();
	Panel1v3 p1 = new Panel1v3();
	PanelPsnjv3 pp;
	int paneles;
	ArrayList<PanelPsnjv3> panel = new ArrayList<>();
	Color colores[] = { new Color(255, 204, 204), new Color(255, 255, 204), new Color(204, 255, 204),
			new Color(204, 255, 255) };
	File imgs[] = { new File("src/Reina.png"), new File("src/Rey.png"), new File("src/Caballero.png"),
			new File("src/Bufon.png") };

	public Color[] getColores() {
		return colores;
	}

	public void setColores(Color[] colores) {
		this.colores = colores;
	}

	public File[] getImgs() {
		return imgs;
	}

	public void setImgs(File[] imgs) {
		this.imgs = imgs;
	}

	public Panel1v3 getP1() {
		return p1;
	}

	public void setP1(Panel1v3 p1) {
		this.p1 = p1;
	}

	public PanelPsnjv3 getPp() {
		return pp;
	}

	public void setPp(PanelPsnjv3 pp) {
		this.pp = pp;
	}

	public ArrayList<Player> getPlayers() {
		return players;
	}

	public void setPlayers(ArrayList<Player> players) {
		this.players = players;
	}

	public ArrayList<PanelPsnjv3> getPanel() {
		return panel;
	}

	public void setPanel(ArrayList<PanelPsnjv3> panel) {
		this.panel = panel;
	}

	public int getPaneles() {
		return paneles;
	}

	public void setPaneles(int paneles) {
		this.paneles = paneles;
	}

	public Bt1v3 getB1() {
		return b1;
	}

	public void setB1(Bt1v3 b1) {
		this.b1 = b1;
	}

	public Ventana3() {
		setBounds(0, 0, 1280, 760);
		setLayout(null);
		setResizable(false);

		JLabel img = new JLabel();
		img.setBounds(0, 0, 1280, 720);

		BufferedImage bi = null;

		try {
			bi = ImageIO.read(new File("src/f3.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		Image redimensionado = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
		img.setIcon(new ImageIcon(redimensionado));
		img.setVisible(true);

		add(p1);
		add(t1);
		add(t2);
		add(b1);
		add(img);
	}

	public void dibujarpaneles() {

		for (int i = 0; i < paneles; i++) {
			pp = new PanelPsnjv3();
			p = new Player();
			pp.setBackground(colores[i]);
			pp.getBp1().setActionCommand("reina" + i);
			pp.getBp2().setActionCommand("rey" + i);
			pp.getBp3().setActionCommand("caballero" + i);
			pp.getBp4().setActionCommand("bufon" + i);
			p1.add(pp);
			panel.add(pp);
			players.add(p);
		}

		int aux = 16;

		for (int k = 0; k < panel.size(); k++) {
			aux = aux + (panel.get(k).getWidth() + 16);
		}

		int aux2 = 0;

		for (int j = 0; j < panel.size(); j++) {
			panel.get(j).setLocation((((p1.getWidth() - aux) / 2) + 16) + aux2, 0);
			aux2 = aux2 + panel.get(j).getWidth() + 16;
		}
	}
}
