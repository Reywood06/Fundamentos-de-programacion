package Vista;

import javax.swing.JPanel;

public class Panel1v4 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Panel1v4() {
		
		setBounds(545,0,720,720);
		setOpaque(false);
		setLayout(null);
		setVisible(true);
	}
}
