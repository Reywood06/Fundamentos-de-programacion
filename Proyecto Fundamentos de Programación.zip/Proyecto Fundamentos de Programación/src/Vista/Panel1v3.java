package Vista;

import javax.swing.JPanel;

public class Panel1v3 extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Panel1v3() {
		
		setBounds(150,150,980,420);
		setOpaque(false);
		setLayout(null);
		setVisible(true);
	}

}
