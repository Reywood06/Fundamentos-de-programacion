package Vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Panelcyfv2 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Font fuente = new Font("Alagard", Font.BOLD, 32);
	Font fuentetx = new Font("Alagard", Font.BOLD, 19);

	JLabel tx1 = new JLabel();

	JTextField cc = new JTextField();
	JTextField cf = new JTextField();

	public JTextField getCc() {
		return cc;
	}

	public void setCc(JTextField cc) {
		this.cc = cc;
	}

	public JTextField getCf() {
		return cf;
	}

	public void setCf(JTextField cf) {
		this.cf = cf;
	}
	
	public Panelcyfv2() {
		
		setBounds(340,360,290,200);
		setBackground(new Color(250,235,195));
		setLayout(null);
		tx1.setBounds(20,20,250,90);
		tx1.setText("<html>Ingresa la cantidad de columnas y filas que deseas agregar al tablero (mínimo 8, máximo 15)<html>");
		tx1.setFont(fuentetx);
		tx1.setVisible(true);
		cc.setBounds(20,130,115,50);
		cc.setFont(fuente);
		cc.setForeground(Color.black);
		cc.setVisible(true);
		cf.setBounds(155,130,115,50);
		cf.setFont(fuente);
		cf.setForeground(Color.black);
		cf.setVisible(true);
		add(tx1);
		add(cc);
		add(cf);
		setVisible(true);
	}
}
