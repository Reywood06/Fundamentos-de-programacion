package Vista;

import javax.swing.JPanel;

public class Casilla extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Casilla() {
		
	}

}
