package Controlador;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import Vista.*;

public class Controlador implements ActionListener {

	Ventana1 v1;
	Ventana2 v2;
	Ventana3 v3;
	Ventana4 v4;

	public Controlador() {

		v1 = new Ventana1();
		v2 = new Ventana2();
		v3 = new Ventana3();
		v4 = new Ventana4();
		v1.getB1().addActionListener(this);
		v1.getB2().addActionListener(this);
	}

	public void jugar() {
		v1.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("iniciar")) {
			v2.setVisible(true);
			v2.getB1().addActionListener(this);
			v1.setVisible(false);
		}

		if (e.getActionCommand().equals("salir")) {
			v1.dispose();

		}

		if (e.getActionCommand().equals("continuar")) {
			try {
				v2.getTb1().setColumnas(Integer.parseInt(v2.getPcf().getCc().getText()));
				v2.getTb1().setFilas(Integer.parseInt(v2.getPcf().getCf().getText()));
				v4.setColumnas(v2.getTb1().getColumnas());
				v4.setFilas(v2.getTb1().getFilas());

				if (v4.getColumnas() < 8 || v4.getColumnas() > 15 || v4.getFilas() < 8 || v4.getFilas() > 15) {
					throw new Exception();
				}

				if (v2.getPcp().getB1().isSelected()) {
					v2.getTb1().setColor1(new Color(70, 110, 200));
					v2.getTb1().setColor2(new Color(120, 125, 170));
					v2.getTb1().setCantjug(1);
					v3.setPaneles(v2.getTb1().getCantjug());
					
					JLabel img = new JLabel();
					img.setSize(v4.getFondo().getWidth(),v4.getFondo().getHeight());
					BufferedImage bi = null;
					
					try {
						bi = ImageIO.read(v4.getImgfondo()[0]);
					}catch(IOException ioe) {
						ioe.printStackTrace();
					}
					
					Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
					img.setIcon(new ImageIcon(redi));
					
					v4.setFondo(img);
				} else if (v2.getPcp().getB2().isSelected()) {
					v2.getTb1().setColor1(new Color(155, 220, 90));
					v2.getTb1().setColor2(new Color(210, 175, 140));
					v2.getTb1().setCantjug(2);
					v3.setPaneles(v2.getTb1().getCantjug());
					
					JLabel img = new JLabel();
					img.setSize(v4.getFondo().getWidth(),v4.getFondo().getHeight());
					BufferedImage bi = null;
					
					try {
						bi = ImageIO.read(v4.getImgfondo()[1]);
					}catch(IOException ioe) {
						ioe.printStackTrace();
					}
					
					Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
					img.setIcon(new ImageIcon(redi));
					
					v4.setFondo(img);
				} else if (v2.getPcp().getB3().isSelected()) {
					v2.getTb1().setColor1(new Color(100, 200, 250));
					v2.getTb1().setColor2(new Color(200, 230, 240));
					v2.getTb1().setCantjug(3);
					v3.setPaneles(v2.getTb1().getCantjug());
					
					JLabel img = new JLabel();
					img.setSize(v4.getFondo().getWidth(),v4.getFondo().getHeight());
					BufferedImage bi = null;
					
					try {
						bi = ImageIO.read(v4.getImgfondo()[2]);
					}catch(IOException ioe) {
						ioe.printStackTrace();
					}
					
					Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
					img.setIcon(new ImageIcon(redi));
					
					v4.setFondo(img);
				} else if (v2.getPcp().getB4().isSelected()) {
					v2.getTb1().setColor1(new Color(210, 50, 10));
					v2.getTb1().setColor2(new Color(250, 160, 10));
					v2.getTb1().setCantjug(4);
					v3.setPaneles(v2.getTb1().getCantjug());
					
					JLabel img = new JLabel();
					img.setSize(v4.getFondo().getWidth(),v4.getFondo().getHeight());
					BufferedImage bi = null;
					
					try {
						bi = ImageIO.read(v4.getImgfondo()[3]);
					}catch(IOException ioe) {
						ioe.printStackTrace();
					}
					
					Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
					img.setIcon(new ImageIcon(redi));
					
					v4.setFondo(img);
				} else {
					throw new Exception();
				}

				v3.dibujarpaneles();
				v3.setVisible(true);
				v3.getB1().addActionListener(this);
				for (int h = 0; h<v3.getPlayers().size(); h++) {
					v3.getPanel().get(h).getBp1().addActionListener(this);
					v3.getPanel().get(h).getBp2().addActionListener(this);
					v3.getPanel().get(h).getBp3().addActionListener(this);
					v3.getPanel().get(h).getBp4().addActionListener(this);
				}
				v2.setVisible(false);
				v4.medida();

			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null,
						"Debes seleccionar una cantidad de jugadore y(o) indicar la cantidad de columnas y filas correctamente");
			}
		}

		if (e.getActionCommand().equals("jugar")) {
			try {
				
				for (int i = 0; i < v3.getPlayers().size(); i++) {
					v3.getPlayers().get(i).setNombre(v3.getPanel().get(i).getNombrejg().getText());
				}

				for (int j = 0; j < v3.getPlayers().size(); j++) {
					if (v3.getPlayers().get(j).getNombre().equals("")) {
						throw new Exception();
					}
				}

				for (int k = 0; k < v3.getPlayers().size(); k++) {
					v3.getPlayers().get(k).setColor(v3.getColores()[k]);
				}
				
				for (int m = 0; m<v3.getPlayers().size();m++) {
					if(v3.getPlayers().get(m).getPsnj().equals(null)) {
						throw new Exception();
					}
				}
				
				v4.setColor1(v2.getTb1().getColor1());
				v4.setColor2(v2.getTb1().getColor2());
				v4.dibujartablero();
				v4.setVisible(true);
				v3.setVisible(false);

			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "Debes seleccionar un personaje y(o) poner tu nombre");
			}
		}

//Button selection and set enabled false other buttons

		if (e.getActionCommand().equals("reina0")) {
			int aux = 0;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[0]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp1().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("reina1")) {
			int aux = 1;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[0]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp1().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("reina2")) {
			int aux = 2;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[0]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp1().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("reina3")) {
			int aux = 3;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[0]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp1().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("rey0")) {
			int aux = 0;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[1]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp2().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("rey1")) {
			int aux = 1;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[1]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp2().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("rey2")) {
			int aux = 2;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[1]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp2().setEnabled(false);
				}
			}
		}

		if (e.getActionCommand().equals("rey3")) {
			int aux = 3;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[1]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp2().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("caballero0")) {
			int aux = 0;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[2]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp3().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("caballero1")) {
			int aux = 1;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[2]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp3().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("caballero2")) {
			int aux = 2;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[2]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp3().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("caballero3")) {
			int aux = 3;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[2]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp4().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp3().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("bufon0")) {
			int aux = 0;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[3]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp4().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("bufon1")) {
			int aux = 1;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[3]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp4().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("bufon2")) {
			int aux = 2;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[3]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp4().setEnabled(false);
				}
			}
		}
		
		if (e.getActionCommand().equals("bufon3")) {
			int aux = 3;
			
			JLabel img = new JLabel();
			img.setSize(v4.getMed(),v4.getMed());
			BufferedImage bi = null;
			
			try {
				bi = ImageIO.read(v3.getImgs()[3]);
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
			
			Image redi = bi.getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_SMOOTH);
			img.setIcon(new ImageIcon(redi));
			
			v3.getPlayers().get(aux).setPsnj(img);
			
			v3.getPanel().get(aux).getBp1().setEnabled(false);
			v3.getPanel().get(aux).getBp2().setEnabled(false);
			v3.getPanel().get(aux).getBp3().setEnabled(false);
			
			for (int l = 0; l < v3.getPlayers().size(); l++) {
				if (l != aux) {
					v3.getPanel().get(l).getBp4().setEnabled(false);
				}
			}
		}
	}
}