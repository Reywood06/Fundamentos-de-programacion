package Modelo;

import java.awt.Color;

import javax.swing.JLabel;

public class Player {

	private String nombre = "";
	private int movimientos;
	private int puntaje;
	private Color color;
	private JLabel psnj;
	
	public Player() {
		
	}
	
	public JLabel getPsnj() {
		return psnj;
	}

	public void setPsnj(JLabel psnj) {
		this.psnj = psnj;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getMovimientos() {
		return movimientos;
	}

	public void setMovimientos(int movimientos) {
		this.movimientos = movimientos;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
}
