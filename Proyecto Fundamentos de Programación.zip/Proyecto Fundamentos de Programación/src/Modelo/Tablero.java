package Modelo;

import java.awt.Color;

public class Tablero {
	
	private int columnas;
	private int filas;
	private Color color1;
	private Color color2;
	private int cantjug;
	
	public Tablero() {
		
	}

	public int getCantjug() {
		return cantjug;
	}

	public void setCantjug(int cantjug) {
		this.cantjug = cantjug;
	}

	public int getColumnas() {
		return columnas;
	}

	public void setColumnas(int columnas) {
		this.columnas = columnas;
	}

	public int getFilas() {
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	public Color getColor1() {
		return color1;
	}

	public void setColor1(Color color1) {
		this.color1 = color1;
	}

	public Color getColor2() {
		return color2;
	}

	public void setColor2(Color color2) {
		this.color2 = color2;
	}
	
	
}
