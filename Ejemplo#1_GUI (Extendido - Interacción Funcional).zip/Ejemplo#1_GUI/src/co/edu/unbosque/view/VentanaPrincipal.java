package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

public class VentanaPrincipal extends JFrame{

	private PanelCentro pc;
	private JLabel titulo;
	
	public VentanaPrincipal() {
		setTitle("Banco FdP");
		setSize(500,200);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		inicializarComponentes();
		
		setResizable(false);
		setVisible(true);
	}
	
	public void inicializarComponentes() {
		getContentPane().setLayout(new BorderLayout());
		pc = new PanelCentro();
		titulo = new JLabel("BANCO FdP", JLabel.CENTER);
		titulo.setForeground(Color.red);
		titulo.setFont(new Font("",Font.ITALIC,18));
		
		
		
		getContentPane().add(titulo, BorderLayout.NORTH);
		getContentPane().add(pc, BorderLayout.CENTER);
	}
	
	public void mostrarMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}

	public PanelCentro getPc() {
		return pc;
	}

	public void setPc(PanelCentro pc) {
		this.pc = pc;
	}

	public JLabel getTitulo() {
		return titulo;
	}

	public void setTitulo(JLabel titulo) {
		this.titulo = titulo;
	}
	
	
	
}
