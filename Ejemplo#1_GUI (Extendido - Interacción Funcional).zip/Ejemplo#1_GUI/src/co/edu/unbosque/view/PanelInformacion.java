package co.edu.unbosque.view;

import java.awt.GridLayout;

import javax.swing.*;

public class PanelInformacion extends JPanel{
	
	private JLabel lblNombre;
	private JLabel lblEdad;
	private JLabel lblCedula;
	
	private JTextField txtNombre;
	private JTextField txtEdad;
	private JTextField txtCedula;
	
	public PanelInformacion() {
		setLayout(new GridLayout(3,2));
		inicializarComponentes();
		setVisible(true);
	}
	
	public void inicializarComponentes() {
		lblNombre = new JLabel("NOMBRE:");
		lblEdad= new JLabel("EDAD:");
		lblCedula = new JLabel("CEDULA:");
		
		txtNombre = new JTextField();
		txtEdad = new JTextField();
		txtCedula = new JTextField();
		
		add(lblNombre);
		add(txtNombre);
		add(lblEdad);
		add(txtEdad);
		add(lblCedula);
		add(txtCedula);
	}

	public JLabel getLblNombre() {
		return lblNombre;
	}

	public void setLblNombre(JLabel lblNombre) {
		this.lblNombre = lblNombre;
	}

	public JLabel getLblEdad() {
		return lblEdad;
	}

	public void setLblEdad(JLabel lblEdad) {
		this.lblEdad = lblEdad;
	}

	public JLabel getLblCedula() {
		return lblCedula;
	}

	public void setLblCedula(JLabel lblCedula) {
		this.lblCedula = lblCedula;
	}

	public JTextField getTxtNombre() {
		return txtNombre;
	}

	public void setTxtNombre(JTextField txtNombre) {
		this.txtNombre = txtNombre;
	}

	public JTextField getTxtEdad() {
		return txtEdad;
	}

	public void setTxtEdad(JTextField txtEdad) {
		this.txtEdad = txtEdad;
	}

	public JTextField getTxtCedula() {
		return txtCedula;
	}

	public void setTxtCedula(JTextField txtCedula) {
		this.txtCedula = txtCedula;
	}
	
	
	
	
}
