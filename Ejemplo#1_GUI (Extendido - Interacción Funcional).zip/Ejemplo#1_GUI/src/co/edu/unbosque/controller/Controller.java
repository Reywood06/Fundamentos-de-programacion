package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import co.edu.unbosque.model.Persona;
import co.edu.unbosque.view.VentanaPrincipal;

public class Controller implements ActionListener{

	private VentanaPrincipal ventanaprincipal;
	private Persona persona;
	private ArrayList<Persona> listapersonas;

	public Controller() {
		listapersonas = new ArrayList<Persona>();

		ventanaprincipal = new VentanaPrincipal();
		asignarOyentes();
	}

	public void asignarOyentes() {
		ventanaprincipal.getPc().getPb().getBtnAgregar().addActionListener(this);
		ventanaprincipal.getPc().getPb().getBtnEliminar().addActionListener(this);
		ventanaprincipal.getPc().getPb().getBtnActualizar().addActionListener(this);
		ventanaprincipal.getPc().getPr().getBtnVerLista().addActionListener(this);
	}

	public void agregarPersona(String nombre, int edad, String cedula) {
		Persona nuevaPersona = new Persona(nombre,edad,cedula);

		if(listapersonas.size()==0) {
			listapersonas.add(nuevaPersona);
			ventanaprincipal.mostrarMensaje("La persona con NOMBRE: "+nombre+ ", EDAD: "+edad+", CEDULA: "+cedula+ " fue agregada satisfactoriamente");
		}
		else {

			for (int x = 0; x < listapersonas.size(); x++) {
				if(!listapersonas.get(x).getCedula().equals(cedula)) {
					listapersonas.add(nuevaPersona);
					ventanaprincipal.mostrarMensaje("La persona con NOMBRE: "+nombre+ ", EDAD: "+edad+", CEDULA: "+cedula+ " fue agregada satisfactoriamente");
				}
				else {
					ventanaprincipal.mostrarMensaje("La persona con cedula "+cedula+" ya esciste en la lista de personas.");
				}
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String comando = e.getActionCommand();

		if(comando.equals("AGREGAR")) {

			if(ventanaprincipal.getPc().getPr().getPanelinfo().getTxtNombre().getText().isEmpty()
					|| ventanaprincipal.getPc().getPr().getPanelinfo().getTxtEdad().getText().isEmpty()
					|| ventanaprincipal.getPc().getPr().getPanelinfo().getTxtCedula().getText().isEmpty()) {

				ventanaprincipal.mostrarMensaje("Debes ingresar todos los valores solicitados para agregar una nueva persona");		

			}
			else {


				String nombre = ventanaprincipal.getPc().getPr().getPanelinfo().getTxtNombre().getText();
				int edad = Integer.parseInt(ventanaprincipal.getPc().getPr().getPanelinfo().getTxtEdad().getText());
				String cedula =ventanaprincipal.getPc().getPr().getPanelinfo().getTxtCedula().getText();

				agregarPersona(nombre, edad, cedula);
				
				ventanaprincipal.getPc().getPr().getPanelinfo().getTxtCedula().setText("");
				ventanaprincipal.getPc().getPr().getPanelinfo().getTxtNombre().setText("");
				ventanaprincipal.getPc().getPr().getPanelinfo().getTxtEdad().setText("");

				
			}		


		}
		if(comando.equals("ELIMINAR")) {
			JOptionPane.showMessageDialog(null, "Se ha oprimido el boton ELIMINAR");

		}
		if(comando.equals("ACTUALIZAR")) {
			JOptionPane.showMessageDialog(null, "Se ha oprimido el boton ACTUALIZAR");

		}
		if(comando.equals("VER")) {
			JOptionPane.showMessageDialog(null, "Se ha oprimido el boton VER");

		}

	}

}
