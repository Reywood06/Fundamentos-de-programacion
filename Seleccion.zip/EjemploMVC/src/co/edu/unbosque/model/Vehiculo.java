package co.edu.unbosque.model;

public class Vehiculo {
	
	private int kilometraje;
	
	public Vehiculo() {
		kilometraje = 0;
	}

	public int getKilometraje() {
		return kilometraje;
	}

	public void setKilometraje(int kilometraje) {
		this.kilometraje = kilometraje;
	}
	
	

}
