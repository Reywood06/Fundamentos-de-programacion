package co.edu.unbosque.controller;

import co.edu.unbosque.model.Cilindro;
import co.edu.unbosque.model.Vehiculo;
import co.edu.unbosque.view.Vista;

public class Controlador {

	private Vehiculo cosmo;
	private Vista wanda;
	private Cilindro juanisimo;
	private int seleccion;

	public Controlador() {
		cosmo = new Vehiculo();
		wanda = new Vista();
		juanisimo = new Cilindro(0,0);
		seleccion = -1;
		funcionar();
	}

	//Ejercicio 1
	public int calcularAlquiler(int km) {
		int respuesta = 0;

		wanda.mostrarInfo("Escriba el kilometraje que tiene el carro:");
		km = wanda.leerDato();
		cosmo.setKilometraje(km);

		if(km<=300 && km>0) {
			respuesta = 30;
			wanda.mostrarInfo("El valor del alquiler para el kilometraje ingresado es: "+ respuesta);
		}
		else if(km>300) {
			respuesta = 30 + 2*km;
			wanda.mostrarInfo("El valor del alquiler para el kilometraje ingresado es: "+ respuesta);
		}
		else {
			wanda.mostrarInfo("El kilometraje ingresado no es v�lido.");
		}


		return respuesta;
	}

	//Ejercicio 2
	public double calcularVolumenCilindro(int radio, int altura) {
		double respuesta =0.0;
		wanda.mostrarInfo("Escriba el radio del cilindro:");
		radio = wanda.leerDato();
		juanisimo.setRadio(radio);

		wanda.mostrarInfo("Escriba la alrur del cilindro:");
		altura = wanda.leerDato();
		juanisimo.setAltura(altura);

		respuesta = Math.PI * Math.pow(radio, 2) * altura;

		wanda.mostrarInfo("El volumen del cilindro es: "+respuesta);

		return respuesta;
	}

	public void funcionar() {

		while(seleccion !=0) {


			wanda.mostrarInfo("Selleccione una de las opciones que se listan en el men� a continuaci�n:");
			wanda.mostrarInfo("1- Calcular el precio de un vehiculo dado su kilometraje");
			wanda.mostrarInfo("2- Calcular el volumen de un cilindro");
			wanda.mostrarInfo("0- SALIR");

			seleccion = wanda.leerDato();

			switch(seleccion) {
			case 1:
				calcularAlquiler(cosmo.getKilometraje());
				break;

			case 2: 
				calcularVolumenCilindro(juanisimo.getRadio(), juanisimo.getAltura());
				break;

			case 0:
				wanda.mostrarInfo("Muchas gracias. Adi�s!");
				break;

			}

		}


	}
}
