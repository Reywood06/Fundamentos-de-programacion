package co.edu.unbosque.view;

import java.util.Scanner;

public class Vista {
	
	private Scanner leer;
	
	public Vista() {
		leer = new Scanner(System.in);
	}
	
	public void mostrarInfo(String m) {
		System.out.println(m);
	}
	
	public int leerDato() {
		int dato =0;
		
		dato = leer.nextInt();
		
		return dato;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
